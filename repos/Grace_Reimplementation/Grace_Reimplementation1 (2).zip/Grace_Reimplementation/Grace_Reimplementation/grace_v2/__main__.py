from grace_v2.train import main

if __name__ == "__main__":
    main()

